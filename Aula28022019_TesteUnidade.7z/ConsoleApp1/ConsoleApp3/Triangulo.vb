﻿Public Class Triangulo

End Class
